# Lab 6 - NLP Fundamentals (Task 2: Chunking and Semantic Suggestions)

All text is synthetic teaching data, not real university policy.

## Setup
```
python -m venv .venv
.venv\Scripts\Activate.ps1        # Windows PowerShell  (macOS/Linux: source .venv/bin/activate)
python -m pip install -r requirements.txt
python -m pip freeze > requirements.txt   # records exact versions for submission
```
The first embedding run downloads `sentence-transformers/all-MiniLM-L6-v2` (needs internet).

## Files
| File | Purpose |
|---|---|
| `lab6_search.py` | Shared Retriever (TF-IDF / embedding) - from the lab manual |
| `task2_chunks.py` | Chunking module: `windows`, `sentence_chunks`, `make_chunks`; run it to execute edge-case tests |
| `task2_corpus.py` | 3 documents (155-158 words), labelled rule+exception evidence, 3 paraphrased queries |
| `task2_analysis.py` | Compares window-0, window-10, sentence-aware (counts, sizes, duplication, evidence kept whole) |
| `task2_semantic.py` | TF-IDF vs real embeddings on the chunks; prints chunk IDs, offsets, evidence check |
| `guided_*.py`, `task1_chatbot_check.py` | Guided examples required by the lab |
| `task2_analysis_output.txt` | Saved output of `task2_analysis.py` |

## Commands (Task 2)
```
python task2_chunks.py                       # edge-case tests: empty, short doc, invalid overlap, long sentence
python guided_chunks.py                      # guided boundary example
python task2_analysis.py                     # strategy comparison
python guided_embeddings.py                  # needs model download
python guided_suggestions.py --backend embedding
python guided_suggestions.py --backend embedding --query "forgot login"
python task2_semantic.py --strategy sentence # also try 0 and 10
```
