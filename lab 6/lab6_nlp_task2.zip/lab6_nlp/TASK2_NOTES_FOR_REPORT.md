# What you must fill in yourself for the report

Measured (already run, see task2_analysis_output.txt):
- Chunk counts: window-0 = 12, window-10 = 15, sentence = 19 (3 docs, 470 words)
- Duplicated words: window-0 = 0, window-10 = 120, sentence = 0
- Evidence kept whole: window-0 -> handbook only; window-10 -> remote_work only;
  sentence -> all three. (Overlap helped one document and hurt another: the
  boundaries just move.)
- Sentence splitter failure: false cuts after "e.g." and "Dr." in handbook.

NOT yet run (needs the model download - run on your machine, paste real output):
- guided_embeddings.py, guided_suggestions.py --backend embedding,
  task2_semantic.py embedding section.
- Do not invent these numbers. Record actual rankings, including failures.

TF-IDF observation (real, from task2_semantic.py): for the paraphrased
"account / login" query the full-evidence chunk it_help:3 ranked 3rd (0.090) behind
a chunk that only mentions the account; the freelance/work-from-home query
did not retrieve remote_work evidence at all in the top 3.
