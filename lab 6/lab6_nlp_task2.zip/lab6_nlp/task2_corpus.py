"""Synthetic teaching documents (NOT real university policies).
Each document has a rule + exception, one sentence longer than 40 words,
and an abbreviation that breaks the simple sentence splitter."""

DOCS = {
"handbook": (
"Assessment Handbook, synthetic version 1. All assignments must be uploaded "
"to the learning portal before the stated deadline, and the portal records "
"the exact time of every upload for later checking by the course instructor, "
"the examination office, and, if a dispute arises, the academic appeals "
"committee that reviews the case. Late submission is normally penalized by "
"ten percent for each day after the deadline. Illness extensions require "
"medical evidence before the deadline. Students who cannot obtain a "
"certificate in time should contact the coordinator, e.g. by email, and "
"explain the reason as early as possible. Dr. Khan, the assessment "
"coordinator, reviews each request personally and replies within two working "
"days. Group work follows the same deadline rules, although every member "
"must confirm the final file before it is uploaded. Plagiarism is reported "
"to the disciplinary office. Marks are released within two weeks of the "
"deadline, and students may ask for feedback during office hours."),

"it_help": (
"IT Help Desk Guide, synthetic version 1. The university account gives "
"access to email, the learning portal, the library catalogue, the campus "
"wireless network, and the shared printers, so students are advised to keep "
"the password private and to change it whenever they suspect that another "
"person has seen it or used it on a public computer. Reset a forgotten "
"password using the recovery link on the login page. Recovery links expire "
"after thirty minutes, and a new link must be requested after that time. "
"Never share recovery codes with anyone, including staff, because the help "
"desk will never ask for them. If the recovery email does not arrive, check "
"the spam folder first. The Wi-Fi network is available in all buildings, "
"i.e. classrooms, labs, and the library, but guests need a temporary "
"voucher from the front desk. Printer quotas reset on the first day of each "
"month. Report broken equipment to the help desk by ticket."),

"remote_work": (
"Remote Work Policy, synthetic version 1. This policy describes who may work "
"away from the office and under which conditions, and it applies to the "
"academic departments, the administrative units, and the support teams, "
"although each manager remains responsible for deciding whether the "
"business needs of the team allow a particular arrangement at a particular "
"time of the year. Employees may request remote work with manager approval. "
"Contractors can work remotely only if the signed contract permits it. "
"Employee rules do not apply to contractors. Approved arrangements are "
"reviewed every six months, and managers may withdraw approval with two "
"weeks of notice. Staff working remotely must be reachable during core "
"hours, i.e. ten to three. Equipment loaned by the university, e.g. a "
"laptop, must be returned when the arrangement ends. Security rules for "
"home networks are published by the IT office. Questions go to the human "
"resources office, and urgent matters may be raised with the department head."),
}

# Evidence = exact substring holding the full rule AND its exception/condition.
EVIDENCE = {
"handbook": ("Late submission is normally penalized by ten percent for each "
             "day after the deadline. Illness extensions require medical "
             "evidence before the deadline."),
"it_help": ("Reset a forgotten password using the recovery link on the login "
            "page. Recovery links expire after thirty minutes, and a new link "
            "must be requested after that time."),
"remote_work": ("Contractors can work remotely only if the signed contract "
                "permits it. Employee rules do not apply to contractors."),
}

# Three paraphrased queries (little keyword overlap with the evidence).
QUERIES = [
    ("I was sick, can I hand in my work after the due date?", "handbook"),
    ("How can I regain access to my account if I forgot my login?", "it_help"),
    ("Is someone on a freelance agreement allowed to work from home?",
     "remote_work"),
]
