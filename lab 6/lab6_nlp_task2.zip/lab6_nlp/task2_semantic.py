"""Task 2 part 2: TF-IDF vs real sentence embeddings on chunks of the corpus.
Run: python task2_semantic.py [--strategy sentence|0|10]"""
import argparse
from task2_chunks import make_chunks
from task2_corpus import DOCS, EVIDENCE, QUERIES
from lab6_search import Retriever


def run(strategy):
    chunks = make_chunks(DOCS, strategy)
    for backend in ["tfidf", "embedding"]:
        print("=" * 70, f"\nBackend: {backend} | strategy: {strategy} "
              f"| chunks: {len(chunks)}")
        try:
            engine = Retriever(chunks, backend)
        except Exception as e:      # e.g. model could not be downloaded
            print("Could not build backend:", type(e).__name__, e)
            continue
        for query, doc in QUERIES:
            print(f"\nQuery: {query}   (expected doc: {doc})")
            hits = engine.search(query, k=3)
            if not hits:
                print("  No matching records (no vocabulary overlap).")
            for rank, (r, score) in enumerate(hits, 1):
                full = (r["doc"] == doc and EVIDENCE[doc] in r["text"])
                print(f"  {rank}. {r['id']} score={score:.3f} "
                      f"chars {r['start']}-{r['end']} full-evidence={full}")
                print("     ", r["text"][:160].replace("\n", " "), "...")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--strategy", default="sentence",
                   choices=["0", "10", "sentence"])
    run(p.parse_args().strategy)
