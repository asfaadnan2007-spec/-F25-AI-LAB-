"""Task 2 analysis: compare 40-word windows (overlap 0 and 10) with
sentence-aware packing (40-word budget) on the synthetic corpus."""
import re
from task2_chunks import make_chunks, windows, sentence_chunks
from task2_corpus import DOCS, EVIDENCE

STRATS = [("window-0", "0"), ("window-10", "10"), ("sentence", "sentence")]


def survives(chunks, doc, evidence):
    """True if one chunk of `doc` contains the full evidence (by offsets)."""
    a = DOCS[doc].index(evidence); b = a + len(evidence)
    return any(c["doc"] == doc and c["start"] <= a and b <= c["end"]
               for c in chunks)


def main():
    orig_words = sum(len(t.split()) for t in DOCS.values())
    print(f"Documents: {len(DOCS)}; original words: {orig_words}")
    for d, t in DOCS.items():
        print(f"  {d}: {len(t.split())} words, {len(t)} chars")
    print()
    print(f"{'strategy':10} {'chunks':>6} {'avg_w':>6} {'min_w':>6} {'max_w':>6} "
          f"{'dup_w':>6}  evidence kept whole")
    for name, strat in STRATS:
        ch = make_chunks(DOCS, strat)
        sizes = [len(c["text"].split()) for c in ch]
        dup = sum(sizes) - orig_words          # emitted words - original words
        kept = {d: survives(ch, d, EVIDENCE[d]) for d in DOCS}
        print(f"{name:10} {len(ch):6} {sum(sizes)/len(sizes):6.1f} {min(sizes):6} "
              f"{max(sizes):6} {dup:6}  {kept}")
        for c in ch:       # traceability check
            assert c["text"] == DOCS[c["doc"]][c["start"]:c["end"]]
    print("\nChunk boundaries (doc:index start-end words):")
    for name, strat in STRATS:
        print(" ", name, [(c["id"], c["start"], c["end"],
              len(c["text"].split())) for c in make_chunks(DOCS, strat)])

    print("\nSentence-splitter failure demo (abbreviations):")
    t = DOCS["handbook"]
    for m in re.finditer(r"[.!?]\s+", t):
        before = t[max(0, m.start()-6):m.end()].replace("\n", " ")
        if re.search(r"(e\.g|i\.e|Dr)\.\s*$", t[:m.end()].rstrip()):
            print("  false boundary after:", repr(before))


if __name__ == "__main__":
    main()
