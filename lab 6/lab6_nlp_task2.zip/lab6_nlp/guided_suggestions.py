import argparse
from guided_chatbot import build_bot
p = argparse.ArgumentParser()
p.add_argument("--backend", choices=["tfidf", "embedding"], default="tfidf")
p.add_argument("--query", default="assignment upload")
a = p.parse_args()
engine = build_bot(a.backend)
print("Suggested questions:")
for record, score in engine.search(a.query, k=3):
    # score > 0 is a lexical-overlap rule only; do NOT use it as an
    # embedding cutoff (embedding scores are rarely <= 0).
    if a.backend == "embedding" or score > 0:
        print(record["question"], f"({score:.3f})")
